CREATE DATABASE DBMS_PROJECT;
USE DBMS_PROJECT;

CREATE TABLE login(
    username VARCHAR(20) NOT NULL,
    password VARCHAR(20) NOT NULL
);

INSERT INTO login VALUES ('admin','admin');

#table 1
CREATE TABLE User(
    User_ID int NOT NULL,
    Name varchar(20) NOT NULL,
    Date_of_Birth date NOT NULL,
    Medical_insurance int,
    Medical_history varchar(20),
    Street varchar(20),
    City varchar(20),
    State varchar(20),
    PRIMARY KEY(User_ID)
);

#table 2
CREATE TABLE User_phone_no(
    User_ID int NOT NULL,
    phone_no varchar(15),
    FOREIGN KEY(User_ID) REFERENCES User(User_ID) ON DELETE CASCADE ON UPDATE CASCADE
);

#table 3
CREATE TABLE Organization(
  Organization_ID int NOT NULL,
  Organization_name varchar(20) NOT NULL,
  Location varchar(20),
  Government_approved int, # 0 or 1
  PRIMARY KEY(Organization_ID)
);

#table 4
CREATE TABLE Doctor(
  Doctor_ID int NOT NULL,
  Doctor_Name varchar(20) NOT NULL,
  Department_Name varchar(20) NOT NULL,
  organization_ID int NOT NULL,
  FOREIGN KEY(organization_ID) REFERENCES Organization(organization_ID) ON DELETE CASCADE ON UPDATE CASCADE,
  PRIMARY KEY(Doctor_ID)
);

#table 5
CREATE TABLE Patient(
    Patient_ID int NOT NULL,
    organ_req varchar(20) NOT NULL,
    reason_of_procurement varchar(20),
    Doctor_ID int NOT NULL,
    User_ID int NOT NULL,
    FOREIGN KEY(User_ID) REFERENCES User(User_ID) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY(Doctor_ID) REFERENCES Doctor(Doctor_ID) ON DELETE CASCADE ON UPDATE CASCADE,
    PRIMARY KEY(Patient_Id, organ_req)
);

#table 6
CREATE TABLE Donor(
  Donor_ID int NOT NULL,
  organ_donated varchar(20) NOT NULL,
  reason_of_donation varchar(20),
  Organization_ID int NOT NULL,
  User_ID int NOT NULL,
  FOREIGN KEY(User_ID) REFERENCES User(User_ID) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY(Organization_ID) REFERENCES Organization(Organization_ID) ON DELETE CASCADE ON UPDATE CASCADE,
  PRIMARY KEY(Donor_ID, organ_donated)
);

#table 7
CREATE TABLE Organ_available(
  Organ_ID int NOT NULL AUTO_INCREMENT,
  Organ_name varchar(20) NOT NULL,
  Donor_ID int NOT NULL,
  FOREIGN KEY(Donor_ID) REFERENCES Donor(Donor_ID) ON DELETE CASCADE ON UPDATE CASCADE,
  PRIMARY KEY(Organ_ID)
);

#table 8
CREATE TABLE Transaction(
  Patient_ID int NOT NULL,
  Organ_ID int NOT NULL,
  Donor_ID int NOT NULL,
  Date_of_transaction date NOT NULL,
  Status int NOT NULL, #0 or 1
  FOREIGN KEY(Patient_ID) REFERENCES Patient(Patient_ID) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY(Donor_ID) REFERENCES Donor(Donor_ID) ON DELETE CASCADE ON UPDATE CASCADE,
  PRIMARY KEY(Patient_ID,Organ_ID)
);

#table 9
CREATE TABLE Organization_phone_no(
  Organization_ID int NOT NULL,
  Phone_no varchar(15),
  FOREIGN KEY(Organization_ID) REFERENCES Organization(Organization_ID) ON DELETE CASCADE ON UPDATE CASCADE
);

#table 10
CREATE TABLE Doctor_phone_no(
  Doctor_ID int NOT NULL,
  Phone_no varchar(15),
  FOREIGN KEY(Doctor_ID) REFERENCES Doctor(Doctor_ID) ON DELETE CASCADE ON UPDATE CASCADE
);

#table 11
CREATE TABLE Organization_head(
  Organization_ID int NOT NULL,
  Employee_ID int NOT NULL,
  Name varchar(20) NOT NULL,
  Date_of_joining date NOT NULL,
  Term_length int NOT NULL,
  FOREIGN KEY(Organization_ID) REFERENCES Organization(Organization_ID) ON DELETE CASCADE ON UPDATE CASCADE,
  PRIMARY KEY(Organization_ID,Employee_ID)
);

-- -------------TRIGGERS --------------
delimiter //
create trigger ADD_DONOR
after insert
on Donor
for each row
begin
insert into Organ_available(Organ_name, Donor_ID)
values (new.organ_donated, new.Donor_ID);
end//
delimiter ;

delimiter //
create trigger REMOVE_ORGAN
after insert
on Transaction
for each row
begin
delete from Organ_available
where Organ_ID = new.Organ_ID;
end//
delimiter ;

create table log (
  querytime datetime,
  comment varchar(255)
);

delimiter //
create trigger ADD_DONOR_LOG
after insert
on Donor
for each row
begin
insert into log values
(now(), concat("Inserted new Donor", cast(new.Donor_Id as char)));
end //

create trigger UPD_DONOR_LOG
after update
on Donor
for each row
begin
insert into log values
(now(), concat("Updated Donor Details", cast(new.Donor_Id as char)));
end //

delimiter //
create trigger DEL_DONOR_LOG
after delete
on Donor
for each row
begin
insert into log values
(now(), concat("Deleted Donor ", cast(old.Donor_Id as char)));
end //

create trigger ADD_PATIENT_LOG
after insert
on Patient
for each row
begin
insert into log values
(now(), concat("Inserted new Patient ", cast(new.Patient_Id as char)));
end //

create trigger UPD_PATIENT_LOG
after update
on Patient
for each row
begin
insert into log values
(now(), concat("Updated Patient Details ", cast(new.Patient_Id as char)));
end //

create trigger DEL_PATIENT_LOG
after delete
on Donor
for each row
begin
insert into log values
(now(), concat("Deleted Patient ", cast(old.Donor_Id as char)));
end //

create trigger ADD_TRASACTION_LOG
after insert
on Transaction
for each row
begin
insert into log values
(now(), concat("Added Transaction :: Patient ID : ", cast(new.Patient_ID as char), "; Donor ID : " ,cast(new.Donor_ID as char)));
end //

-- -------------PROCEDURES --------------
DROP PROCEDURE IF EXISTS organsAvailable;
DELIMITER //
CREATE PROCEDURE organsAvailable()
BEGIN
	select *, count(organ_donated) as
    total_count from donor group by organ_donated;
END //
DELIMITER ;
call organsAvailable();


DROP PROCEDURE IF EXISTS patientPersonalDetails;
DELIMITER //
CREATE PROCEDURE patientPersonalDetails()
BEGIN
	select  p.Patient_ID, u.Name as Patient_Name, d.Doctor_Name, u.Street, u.City, u.State, u.Medical_history
	from patient p inner join user u on p.patient_ID=u.user_ID inner join doctor d on
	d.doctor_ID=p.patient_ID;
END //
DELIMITER ;
call patientPersonalDetails();

DROP PROCEDURE IF EXISTS govtApprovedOrg;
DELIMITER //
CREATE PROCEDURE govtApprovedOrg()
BEGIN
	select o.*, op.phone_no from organization o inner join organization_phone_no op 
	on o.organization_ID=op.organization_ID where o.government_approved=1;
END //
DELIMITER ;
call govtApprovedOrg();

-- -------------FUNCTIONS --------------
-- doctors who performed most surgeries
DROP function if exists most_surgeries_performed;
DELIMITER $$
CREATE FUNCTION most_surgeries_performed( )
    RETURNS VARCHAR(20) DETERMINISTIC
    READS SQL DATA
    BEGIN
    DECLARE ret_doc_name VARCHAR(20);
    DECLARE doc_id INT;
        SET doc_id = (SELECT doctor_id FROM (SELECT doctor_id,COUNT(*) AS MAX_Docs
                                             FROM patient
                                             GROUP BY doctor_id
                                             ORDER BY COUNT(*) DESC
                                             LIMIT 1) AS T);
	SET ret_doc_name = (SELECT doctor_name FROM doctor WHERE doctor_id = doc_id);
    RETURN (ret_doc_name);
    END $$
    DELIMITER ;
        
SELECT most_surgeries_performed();


-- organization name with most donors
DROP function if exists org_with_most_donors;
DELIMITER $$
CREATE FUNCTION org_with_most_donors()
    RETURNS VARCHAR(20) DETERMINISTIC
    READS SQL DATA
    BEGIN
    DECLARE ret_org_name VARCHAR(20);
    DECLARE org_id INT;
        SET org_id = (SELECT organization_id FROM (SELECT organization_id,COUNT(*) AS MAX_Donars
                                             FROM donor
                                             GROUP BY organization_id
                                             ORDER BY COUNT(*) DESC
                                             LIMIT 1) AS T);
        SET ret_org_name = (SELECT organization_name FROM organization WHERE organization_id = org_id);
    RETURN (ret_org_name);
    END $$
    DELIMITER ;
    
SELECT org_with_most_donors();

-- Most required organ

DROP FUNCTION if exists most_required_organ;
DELIMITER $$
CREATE FUNCTION most_required_organ()
RETURNS VARCHAR(20) DETERMINISTIC
    READS SQL DATA
    BEGIN
    DECLARE ret_organ VARCHAR(20);
        SET ret_organ = (SELECT organ_req
                        FROM(SELECT organ_req,COUNT(*) AS MAX_Donars
                             FROM patient
                             GROUP BY organ_req
                             ORDER BY COUNT(*) DESC
                             LIMIT 1) AS T);
    RETURN (ret_organ);
    END $$
    DELIMITER ;
    
    
SELECT most_required_organ();

-- most donated organ

DROP FUNCTION if exists most_donated_organ;
DELIMITER $$
CREATE FUNCTION most_donated_organ()
RETURNS VARCHAR(20) DETERMINISTIC
    READS SQL DATA
    BEGIN
    DECLARE ret_organ VARCHAR(20);
        SET ret_organ = (SELECT organ_donated
                        FROM(SELECT organ_donated,COUNT(*) AS MAX_Donars
                             FROM donor
                             GROUP BY organ_donated
                             ORDER BY COUNT(*) DESC
                             LIMIT 1) AS T);
    RETURN (ret_organ);
    END $$
    DELIMITER ;
    
SELECT most_donated_organ();
-- INSERT INTO User VALUES(100,'Random1','2000-01-01',1,NULL,'Street 1','City 1','State 1');
-- INSERT INTO User VALUES(20,'Random2','2000-01-02',1,NULL,'Street 2','City 2','State 2');
