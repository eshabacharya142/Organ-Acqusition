# Organ Acquisition and Donation Management System
## DBMS Project.
#### Designed a database to efficiently organize data regarding organ transplantation network.
#### Created back-end APIs using FLASK framework.

Base requirements - 
Python 3 and MySQL Workbench

Tech Stack - MySQL, Python, Flask, HTML, CSS

How to run this project:

Database steps: 
Execute the following files as SQL scripts:
1. create_tables - This file has table schemas, procedures, functions and triggers.
2. All files in templates/ - These insert data statements to be able to perform CRUD operations.
3. Or database dump provided.

Python steps:
1. Download the following dependencies using pip:
   1. pip install flask
   2. pip install mysql-connector and pip install mysql-connector-python
   3. pip install matplotlib
   4. pip install numpy

2. Make sure to change the password in main.py to your MySQL password. (It exists in 4 places)
3. Open command prompt in the location where the "main.py" file resides.
4. Run this file py main.py
5. The project will be running on localhost:5000
6. Log in using the following credentials username: admin and password:admin